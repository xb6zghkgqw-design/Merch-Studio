# Complete Frontend – Glass Aesthetic

This is a ready-to-run Next.js frontend with a translucent shiny glass design system.

## Features
- Full glassmorphism system (`.glass`, `.glass-strong`, `.glass-card`, `.glass-button`)
- HD-feeling translucent icons via `GlassIcon` component
- Shine hover effects on cards and icons
- Pages: Home, Music, Tour, Merch
- Responsive navigation + footer with newsletter
- Placeholder content ready to be replaced by Payload or Sanity data

## How to run

```bash
cd complete-frontend
npm install
npm run dev
```

You will also need a basic `package.json` and Tailwind config (see below).

## Required setup files

Create these in the same folder:

**package.json** (minimum)
```json
{
  "name": "artist-frontend",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^15",
    "react": "^19",
    "react-dom": "^19"
  },
  "devDependencies": {
    "typescript": "^5",
    "@types/react": "^19",
    "@types/node": "^22",
    "tailwindcss": "^3.4",
    "postcss": "^8",
    "autoprefixer": "^10"
  }
}
```

**tailwind.config.ts**
```ts
import type { Config } from 'tailwindcss'

export default {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
} satisfies Config
```

**postcss.config.mjs**
```js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

## Design notes
- All major UI surfaces use layered translucent glass with blur + inset shine
- Icons sit inside glass containers with soft white glow
- Hover states add extra shine and lift
- Accent color is soft violet (easily changeable in `globals.css`)

Connect this frontend to the Payload or Sanity CMS from the parent folders when ready.
