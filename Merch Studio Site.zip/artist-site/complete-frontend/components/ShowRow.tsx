type Props = {
  date: string
  city: string
  venue?: string
  ticketLink?: string
  isSoldOut?: boolean
}

export function ShowRow({ date, city, venue, ticketLink, isSoldOut }: Props) {
  return (
    <div className="glass-card px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-baseline gap-6">
        <div className="text-sm text-white/50 w-28 shrink-0">{date}</div>
        <div>
          <div className="font-medium text-lg">{city}</div>
          {venue && <div className="text-sm text-white/40">{venue}</div>}
        </div>
      </div>

      <div>
        {isSoldOut ? (
          <span className="text-sm text-white/40 px-4 py-2">Sold Out</span>
        ) : (
          <a
            href={ticketLink || '#'}
            className="glass-button text-sm py-2 px-5"
          >
            Tickets
          </a>
        )}
      </div>
    </div>
  )
}
