type Props = {
  name: string
  price: number
  image?: string
  featured?: boolean
}

export function MerchCard({ name, price, image, featured }: Props) {
  return (
    <div className="glass-card glass-shine overflow-hidden group">
      <div className="aspect-[4/5] bg-white/5 relative">
        {image ? (
          <img src={image} alt={name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white/15 text-5xl">
            ■
          </div>
        )}
        {featured && (
          <div className="absolute top-3 left-3 glass-strong text-xs px-3 py-1 rounded-full">
            Featured
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-medium">{name}</h3>
        <div className="mt-1 flex items-center justify-between">
          <span className="text-white/70">${price}</span>
          <button className="glass-button text-xs py-1.5 px-3">
            Add
          </button>
        </div>
      </div>
    </div>
  )
}
