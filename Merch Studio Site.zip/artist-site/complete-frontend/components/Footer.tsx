import Link from 'next/link'

export function Footer() {
  return (
    <footer className="mt-32 border-t border-white/10">
      <div className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <div className="font-bold text-xl mb-4">ARTIST</div>
            <p className="text-white/50 text-sm leading-relaxed">
              Official site. New music, tour dates, merch, and exclusive drops.
            </p>
          </div>

          <div>
            <div className="text-sm font-medium mb-4 text-white/80">Navigate</div>
            <div className="flex flex-col gap-2 text-sm text-white/50">
              <Link href="/music" className="hover:text-white transition">Music</Link>
              <Link href="/videos" className="hover:text-white transition">Videos</Link>
              <Link href="/tour" className="hover:text-white transition">Tour</Link>
              <Link href="/merch" className="hover:text-white transition">Merch</Link>
              <Link href="/about" className="hover:text-white transition">About</Link>
              <Link href="/press" className="hover:text-white transition">Press</Link>
            </div>
          </div>

          <div>
            <div className="text-sm font-medium mb-4 text-white/80">Newsletter</div>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Email address"
                className="glass flex-1 rounded-full px-4 py-2.5 text-sm outline-none placeholder:text-white/30"
              />
              <button type="submit" className="glass-button-primary rounded-full px-5 text-sm">
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 text-xs text-white/30 flex justify-between">
          <span>© {new Date().getFullYear()} Artist Name</span>
          <span>All rights reserved</span>
        </div>
      </div>
    </footer>
  )
}
