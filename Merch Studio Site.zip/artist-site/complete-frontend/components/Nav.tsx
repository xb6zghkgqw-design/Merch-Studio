import Link from 'next/link'

const links = [
  { href: '/music', label: 'Music' },
  { href: '/videos', label: 'Videos' },
  { href: '/tour', label: 'Tour' },
  { href: '/merch', label: 'Merch' },
  { href: '/about', label: 'About' },
]

export function Nav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <div className="max-w-6xl mx-auto px-6 py-4">
        <nav className="glass-strong rounded-2xl px-6 py-3 flex items-center justify-between">
          <Link href="/" className="font-bold text-lg tracking-tight">
            ARTIST
          </Link>

          <div className="hidden md:flex items-center gap-8 text-sm">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-white/70 hover:text-white transition"
              >
                {link.label}
              </Link>
            ))}
          </div>

          <Link href="/#newsletter" className="glass-button text-sm py-2 px-4">
            Join List
          </Link>
        </nav>
      </div>
    </header>
  )
}
