import React from 'react'

type Props = {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

const sizes = {
  sm: 'w-10 h-10',
  md: 'w-14 h-14',
  lg: 'w-16 h-16',
}

export function GlassIcon({ children, size = 'md', className = '' }: Props) {
  return (
    <div
      className={`
        icon-glass glass-shine
        ${sizes[size]}
        ${className}
      `}
    >
      <div className="relative z-10 text-white/90">
        {children}
      </div>
    </div>
  )
}
