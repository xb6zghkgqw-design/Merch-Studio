import { GlassIcon } from './GlassIcon'

type Props = {
  title: string
  cover?: string
  featured?: boolean
  embedUrl?: string
}

export function TrackCard({ title, cover, featured }: Props) {
  return (
    <div className="glass-card glass-shine p-4 group">
      <div className="aspect-square rounded-xl overflow-hidden bg-white/5 mb-4 relative">
        {cover ? (
          <img src={cover} alt={title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-white/20 text-4xl font-bold">
            ♪
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition" />
      </div>

      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-medium leading-tight">{title}</h3>
          {featured && (
            <span className="text-xs text-violet-300/80 mt-1 inline-block">Featured</span>
          )}
        </div>

        <GlassIcon size="sm">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </GlassIcon>
      </div>
    </div>
  )
}
