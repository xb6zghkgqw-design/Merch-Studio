import { ShowRow } from '../../components/ShowRow'

const shows = [
  { date: 'Jan 15, 2026', city: 'Atlanta, GA', venue: 'The Tabernacle', isSoldOut: false },
  { date: 'Jan 18, 2026', city: 'Charlotte, NC', venue: 'Fillmore', isSoldOut: false },
  { date: 'Jan 22, 2026', city: 'Washington, DC', venue: '9:30 Club', isSoldOut: true },
  { date: 'Feb 05, 2026', city: 'Philadelphia, PA', venue: 'Union Transfer', isSoldOut: false },
  { date: 'Feb 08, 2026', city: 'Brooklyn, NY', venue: 'Music Hall of Williamsburg', isSoldOut: false },
  { date: 'Feb 14, 2026', city: 'Boston, MA', venue: 'Royale', isSoldOut: false },
  { date: 'Mar 01, 2026', city: 'Chicago, IL', venue: 'Metro', isSoldOut: false },
  { date: 'Mar 07, 2026', city: 'Detroit, MI', venue: 'Saint Andrews', isSoldOut: false },
]

export default function TourPage() {
  return (
    <main className="max-w-4xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold mb-2">Tour</h1>
      <p className="text-white/50 mb-12">Upcoming dates</p>

      <div className="space-y-3">
        {shows.map((show) => (
          <ShowRow key={show.city + show.date} {...show} />
        ))}
      </div>
    </main>
  )
}
