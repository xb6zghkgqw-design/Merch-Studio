import { MerchCard } from '../../components/MerchCard'

const items = [
  { name: 'Classic Logo Tee', price: 35, featured: true },
  { name: 'Tour Hoodie', price: 65, featured: true },
  { name: 'Vinyl – Midnight Run', price: 30, featured: false },
  { name: 'Dad Hat', price: 28, featured: false },
  { name: 'Poster Pack', price: 20, featured: false },
  { name: 'Long Sleeve', price: 45, featured: false },
]

export default function MerchPage() {
  return (
    <main className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold mb-2">Merch</h1>
      <p className="text-white/50 mb-12">Official gear</p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {items.map((item) => (
          <MerchCard key={item.name} {...item} />
        ))}
      </div>
    </main>
  )
}
