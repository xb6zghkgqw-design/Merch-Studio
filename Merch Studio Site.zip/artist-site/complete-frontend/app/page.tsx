import Link from 'next/link'
import { TrackCard } from '../components/TrackCard'
import { ShowRow } from '../components/ShowRow'
import { MerchCard } from '../components/MerchCard'
import { GlassIcon } from '../components/GlassIcon'

const placeholderTracks = [
  { title: 'Midnight Run', featured: true },
  { title: 'City Lights', featured: false },
  { title: 'No Sleep', featured: true },
  { title: 'Concrete Dreams', featured: false },
]

const placeholderShows = [
  { date: 'Jan 15, 2026', city: 'Atlanta, GA', venue: 'The Tabernacle', isSoldOut: false },
  { date: 'Jan 18, 2026', city: 'Charlotte, NC', venue: 'Fillmore', isSoldOut: false },
  { date: 'Jan 22, 2026', city: 'Washington, DC', venue: '9:30 Club', isSoldOut: true },
]

const placeholderMerch = [
  { name: 'Classic Logo Tee', price: 35, featured: true },
  { name: 'Tour Hoodie', price: 65, featured: true },
  { name: 'Vinyl – Midnight Run', price: 30, featured: false },
]

export default function HomePage() {
  return (
    <main>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-12 pb-24">
        <div className="glass-strong rounded-3xl p-10 md:p-16 relative overflow-hidden noise">
          <div className="relative z-10 max-w-2xl">
            <p className="text-violet-300/80 text-sm tracking-widest uppercase mb-4">
              New Music
            </p>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
              Midnight<br />Run
            </h1>
            <p className="mt-6 text-lg text-white/60 max-w-md">
              The latest single. Out now on all platforms.
            </p>

            <div className="mt-10 flex flex-wrap gap-4">
              <Link href="/music" className="glass-button-primary">
                Listen Now
              </Link>
              <Link href="/tour" className="glass-button">
                Tour Dates
              </Link>
            </div>
          </div>

          {/* Decorative glass orbs */}
          <div className="absolute -right-20 -top-20 w-72 h-72 rounded-full bg-violet-500/20 blur-3xl" />
          <div className="absolute -right-10 bottom-0 w-48 h-48 rounded-full bg-fuchsia-500/10 blur-2xl" />
        </div>
      </section>

      {/* Featured Tracks */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl font-bold">Featured Tracks</h2>
          <Link href="/music" className="text-sm text-white/50 hover:text-white transition">
            View all →
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {placeholderTracks.map((track) => (
            <TrackCard key={track.title} {...track} />
          ))}
        </div>
      </section>

      {/* Tour teaser */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl font-bold">Upcoming Shows</h2>
          <Link href="/tour" className="text-sm text-white/50 hover:text-white transition">
            Full tour →
          </Link>
        </div>

        <div className="space-y-3">
          {placeholderShows.map((show) => (
            <ShowRow key={show.city} {...show} />
          ))}
        </div>
      </section>

      {/* Merch teaser */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="flex items-end justify-between mb-8">
          <h2 className="text-2xl font-bold">Merch</h2>
          <Link href="/merch" className="text-sm text-white/50 hover:text-white transition">
            Shop all →
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {placeholderMerch.map((item) => (
            <MerchCard key={item.name} {...item} />
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section id="newsletter" className="max-w-6xl mx-auto px-6 py-24">
        <div className="glass-strong rounded-3xl p-10 md:p-14 text-center">
          <GlassIcon size="lg" className="mx-auto mb-6">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
              <polyline points="22,6 12,13 2,6" />
            </svg>
          </GlassIcon>
          <h2 className="text-3xl font-bold">Stay in the loop</h2>
          <p className="mt-3 text-white/50 max-w-md mx-auto">
            New music, tour announcements, and exclusive drops. No spam.
          </p>
          <form className="mt-8 flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email"
              className="glass flex-1 rounded-full px-5 py-3 text-sm outline-none placeholder:text-white/30"
            />
            <button type="submit" className="glass-button-primary">
              Join the list
            </button>
          </form>
        </div>
      </section>
    </main>
  )
}
