import type { Metadata } from 'next'
import '../styles/globals.css'
import { Nav } from '../components/Nav'
import { Footer } from '../components/Footer'

export const metadata: Metadata = {
  title: 'Artist Name – Official Site',
  description: 'Music, videos, tour dates, merch and more.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="antialiased">
        <Nav />
        <div className="pt-28">
          {children}
        </div>
        <Footer />
      </body>
    </html>
  )
}
