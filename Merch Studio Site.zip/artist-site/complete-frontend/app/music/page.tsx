import { TrackCard } from '../../components/TrackCard'

const tracks = [
  { title: 'Midnight Run', featured: true },
  { title: 'City Lights', featured: false },
  { title: 'No Sleep', featured: true },
  { title: 'Concrete Dreams', featured: false },
  { title: 'Late Nights', featured: false },
  { title: 'Rise Up', featured: false },
  { title: 'Shadow Work', featured: false },
  { title: 'After Hours', featured: false },
]

export default function MusicPage() {
  return (
    <main className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-bold mb-2">Music</h1>
      <p className="text-white/50 mb-12">All releases and singles</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {tracks.map((track) => (
          <TrackCard key={track.title} {...track} />
        ))}
      </div>
    </main>
  )
}
