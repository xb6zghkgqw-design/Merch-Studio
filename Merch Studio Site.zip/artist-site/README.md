# Rap Artist Website – Complete Starter Kit

This package contains everything you need to build a professional rap artist website with a secure admin and a modern translucent glass aesthetic.

## What’s included

### 1. `complete-frontend/`
A full Next.js site with:
- Home, Music, Tour, Merch pages
- Translucent shiny glass design system (glass cards, buttons, icons)
- HD-feeling glass icon containers with shine effects
- Newsletter section
- Ready for real data from Payload or Sanity

### 2. `payload/`
Full Payload CMS schemas + config + seed data for:
- Tracks, Videos, Tour Dates, Merch
- Home, Site Settings, About, Press Kit

### 3. `sanity/`
Complete Sanity schemas for the same content model.

### 4. `webflow/` & `framer/`
Detailed step-by-step guides with exact CMS field lists.

## Recommended path

1. Unzip
2. Go into `complete-frontend/`
3. Run `npm install && npm run dev`
4. Open http://localhost:3000 to see the glass-styled site
5. Later connect it to Payload or Sanity for real content editing

## Glass design notes
- All major surfaces use layered translucent glass with blur
- Icons sit in shiny glass containers
- Hover states add extra shine and subtle lift
- Easy to change the accent color in `styles/globals.css`

Replace the placeholder artist name, tracks, dates, and merch with real content through the CMS of your choice.
