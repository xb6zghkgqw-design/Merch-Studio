# Payload CMS + Next.js Starter

## What you get
- Secure admin at `/admin`
- Collections for Tracks, Videos, Tour Dates, Merch
- Globals for Home, Site Settings, About, Press Kit
- Placeholder seed data
- Ready for a Next.js frontend

## Step-by-step setup

1. Create a new Payload app (or use this structure inside a monorepo):
   ```bash
   npx create-payload-app@latest
   ```

2. Copy the files from `src/collections/` and `src/globals/` into your project.

3. Update `payload.config.ts` with the collections and globals (see the example file).

4. Set environment variables:
   ```
   PAYLOAD_SECRET=your-long-random-secret
   DATABASE_URI=postgres://...   # or use SQLite for local
   ```

5. Run the seed script to add placeholder content.

6. Start the admin:
   ```bash
   npm run dev
   ```
   Go to `http://localhost:3000/admin`

7. Connect a Next.js frontend and pull data using the Local API or REST.

## Collections included
- Tracks
- Videos
- Tour Dates
- Merch
- Media (built-in)
- Users (built-in)

## Globals included
- Home
- Site Settings
- About
- Press Kit
