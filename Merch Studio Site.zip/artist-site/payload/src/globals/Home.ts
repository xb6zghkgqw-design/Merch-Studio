import type { GlobalConfig } from 'payload'

export const Home: GlobalConfig = {
  slug: 'home',
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'heroTitle',
      type: 'text',
      label: 'Hero Title',
    },
    {
      name: 'heroSubtitle',
      type: 'text',
      label: 'Hero Subtitle',
    },
    {
      name: 'featuredTrack',
      type: 'relationship',
      relationTo: 'tracks',
      label: 'Featured Track',
    },
    {
      name: 'featuredVideo',
      type: 'relationship',
      relationTo: 'videos',
      label: 'Featured Video',
    },
    {
      name: 'primaryCtaLabel',
      type: 'text',
      label: 'Primary Button Label',
    },
    {
      name: 'primaryCtaLink',
      type: 'text',
      label: 'Primary Button Link',
    },
    {
      name: 'secondaryCtaLabel',
      type: 'text',
      label: 'Secondary Button Label',
    },
    {
      name: 'secondaryCtaLink',
      type: 'text',
      label: 'Secondary Button Link',
    },
  ],
}
