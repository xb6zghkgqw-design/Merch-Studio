import type { GlobalConfig } from 'payload'

export const PressKit: GlobalConfig = {
  slug: 'press-kit',
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'shortBio',
      type: 'textarea',
      label: 'Short Bio (for press)',
    },
    {
      name: 'oneSheet',
      type: 'upload',
      relationTo: 'media',
      label: 'One-Sheet PDF',
    },
    {
      name: 'highResPhotos',
      type: 'array',
      fields: [
        {
          name: 'photo',
          type: 'upload',
          relationTo: 'media',
        },
      ],
    },
    {
      name: 'bookingEmail',
      type: 'text',
      label: 'Booking Email',
    },
    {
      name: 'additionalFiles',
      type: 'array',
      fields: [
        {
          name: 'file',
          type: 'upload',
          relationTo: 'media',
        },
        {
          name: 'label',
          type: 'text',
        },
      ],
    },
  ],
}
