import type { CollectionConfig } from 'payload'

export const TourDates: CollectionConfig = {
  slug: 'tour-dates',
  admin: {
    useAsTitle: 'city',
    defaultColumns: ['date', 'city', 'venue', 'isSoldOut'],
  },
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'date',
      type: 'date',
      required: true,
    },
    {
      name: 'city',
      type: 'text',
      required: true,
    },
    {
      name: 'venue',
      type: 'text',
    },
    {
      name: 'ticketLink',
      type: 'text',
      label: 'Ticket URL',
    },
    {
      name: 'isSoldOut',
      type: 'checkbox',
      defaultValue: false,
    },
  ],
}
