import type { CollectionConfig } from 'payload'

export const Tracks: CollectionConfig = {
  slug: 'tracks',
  admin: {
    useAsTitle: 'title',
    defaultColumns: ['title', 'releaseDate', 'featured'],
  },
  access: {
    read: () => true,
  },
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
    },
    {
      name: 'cover',
      type: 'upload',
      relationTo: 'media',
    },
    {
      name: 'audioFile',
      type: 'upload',
      relationTo: 'media',
    },
    {
      name: 'embedUrl',
      type: 'text',
      label: 'Spotify / Apple Music Embed URL',
    },
    {
      name: 'releaseDate',
      type: 'date',
    },
    {
      name: 'streamingLinks',
      type: 'array',
      fields: [
        {
          name: 'platform',
          type: 'select',
          options: [
            { label: 'Spotify', value: 'spotify' },
            { label: 'Apple Music', value: 'apple' },
            { label: 'YouTube Music', value: 'youtube' },
            { label: 'SoundCloud', value: 'soundcloud' },
            { label: 'Other', value: 'other' },
          ],
        },
        {
          name: 'url',
          type: 'text',
          required: true,
        },
      ],
    },
    {
      name: 'featured',
      type: 'checkbox',
      defaultValue: false,
    },
  ],
}
