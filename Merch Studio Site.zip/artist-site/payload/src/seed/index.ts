/**
 * Simple seed script for placeholder content.
 * Run after the database is set up.
 *
 * Example usage (adjust to your Payload version):
 * npx payload run src/seed/index.ts
 */

export const placeholderTracks = [
  {
    title: 'Midnight Run',
    releaseDate: '2025-11-01',
    featured: true,
    embedUrl: 'https://open.spotify.com/embed/track/example1',
  },
  {
    title: 'City Lights',
    releaseDate: '2025-09-15',
    featured: false,
  },
  {
    title: 'No Sleep',
    releaseDate: '2025-07-20',
    featured: true,
  },
  {
    title: 'Concrete Dreams',
    releaseDate: '2025-05-10',
    featured: false,
  },
  {
    title: 'Late Nights',
    releaseDate: '2025-03-01',
    featured: false,
  },
  {
    title: 'Rise Up',
    releaseDate: '2024-12-15',
    featured: false,
  },
]

export const placeholderVideos = [
  {
    title: 'Midnight Run – Official Video',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    releaseDate: '2025-11-05',
    featured: true,
  },
  {
    title: 'Live at The Vault',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    releaseDate: '2025-08-12',
    featured: false,
  },
  {
    title: 'City Lights – Visualizer',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    releaseDate: '2025-09-20',
    featured: true,
  },
  {
    title: 'Behind the Scenes',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    releaseDate: '2025-06-01',
    featured: false,
  },
]

export const placeholderTourDates = [
  { date: '2026-01-15', city: 'Atlanta, GA', venue: 'The Tabernacle', ticketLink: '#', isSoldOut: false },
  { date: '2026-01-18', city: 'Charlotte, NC', venue: 'Fillmore', ticketLink: '#', isSoldOut: false },
  { date: '2026-01-22', city: 'Washington, DC', venue: '9:30 Club', ticketLink: '#', isSoldOut: true },
  { date: '2026-02-05', city: 'Philadelphia, PA', venue: 'Union Transfer', ticketLink: '#', isSoldOut: false },
  { date: '2026-02-08', city: 'Brooklyn, NY', venue: 'Music Hall of Williamsburg', ticketLink: '#', isSoldOut: false },
  { date: '2026-02-14', city: 'Boston, MA', venue: 'Royale', ticketLink: '#', isSoldOut: false },
  { date: '2026-03-01', city: 'Chicago, IL', venue: 'Metro', ticketLink: '#', isSoldOut: false },
  { date: '2026-03-07', city: 'Detroit, MI', venue: 'Saint Andrews', ticketLink: '#', isSoldOut: false },
]

export const placeholderMerch = [
  {
    name: 'Classic Logo Tee',
    slug: 'classic-logo-tee',
    price: 35,
    stock: 100,
    featured: true,
    sizes: [{ size: 'S' }, { size: 'M' }, { size: 'L' }, { size: 'XL' }],
  },
  {
    name: 'Tour Hoodie',
    slug: 'tour-hoodie',
    price: 65,
    stock: 50,
    featured: true,
    sizes: [{ size: 'M' }, { size: 'L' }, { size: 'XL' }],
  },
  {
    name: 'Vinyl – Midnight Run',
    slug: 'vinyl-midnight-run',
    price: 30,
    stock: 200,
    featured: false,
  },
  {
    name: 'Dad Hat',
    slug: 'dad-hat',
    price: 28,
    stock: 75,
    featured: false,
  },
  {
    name: 'Poster Pack',
    slug: 'poster-pack',
    price: 20,
    stock: 150,
    featured: false,
  },
]
