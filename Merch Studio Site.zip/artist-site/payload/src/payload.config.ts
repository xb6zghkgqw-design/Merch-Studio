import path from 'path'
import { buildConfig } from 'payload'
import { lexicalEditor } from '@payloadcms/richtext-lexical'
import { postgresAdapter } from '@payloadcms/db-postgres' // swap to sqliteAdapter for local-only
import { fileURLToPath } from 'url'

import { Tracks } from './collections/Tracks'
import { Videos } from './collections/Videos'
import { TourDates } from './collections/TourDates'
import { Merch } from './collections/Merch'
import { Home } from './globals/Home'
import { SiteSettings } from './globals/SiteSettings'
import { About } from './globals/About'
import { PressKit } from './globals/PressKit'

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)

export default buildConfig({
  admin: {
    user: 'users',
    importMap: {
      baseDir: path.resolve(dirname),
    },
  },
  collections: [
    Tracks,
    Videos,
    TourDates,
    Merch,
    // Media and Users are usually added by the Payload template
  ],
  globals: [
    Home,
    SiteSettings,
    About,
    PressKit,
  ],
  editor: lexicalEditor(),
  secret: process.env.PAYLOAD_SECRET || 'CHANGE-THIS-TO-A-LONG-RANDOM-SECRET',
  typescript: {
    outputFile: path.resolve(dirname, 'payload-types.ts'),
  },
  db: postgresAdapter({
    pool: {
      connectionString: process.env.DATABASE_URI || '',
    },
  }),
})
