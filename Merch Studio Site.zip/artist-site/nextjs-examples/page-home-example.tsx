// Example Home page (adapt the data fetching to Payload or Sanity)

export default function HomePage() {
  // Replace with real data fetching
  const heroTitle = "Artist Name"
  const heroSubtitle = "New music out now"

  return (
    <main className="min-h-screen bg-black text-white">
      <section className="px-6 py-24 max-w-6xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight">
          {heroTitle}
        </h1>
        <p className="mt-4 text-xl text-neutral-400">
          {heroSubtitle}
        </p>

        <div className="mt-10 flex gap-4">
          <a href="/music" className="bg-white text-black px-6 py-3 font-medium">
            Listen
          </a>
          <a href="/tour" className="border border-white px-6 py-3 font-medium">
            Tour Dates
          </a>
        </div>
      </section>

      {/* Featured track / video sections would go here */}
    </main>
  )
}
