// Example Tour page

type Show = {
  id: string
  date: string
  city: string
  venue?: string
  ticketLink?: string
  isSoldOut?: boolean
}

export default function TourPage({ shows = [] as Show[] }) {
  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto px-6 py-20">
        <h1 className="text-4xl font-bold mb-12">Tour Dates</h1>

        <div className="space-y-4">
          {shows.map((show) => (
            <div
              key={show.id}
              className="flex flex-col md:flex-row md:items-center justify-between border-b border-neutral-800 py-4 gap-4"
            >
              <div>
                <div className="font-medium">{show.date}</div>
                <div className="text-xl">{show.city}</div>
                {show.venue && (
                  <div className="text-neutral-400 text-sm">{show.venue}</div>
                )}
              </div>

              <div>
                {show.isSoldOut ? (
                  <span className="text-neutral-500">Sold Out</span>
                ) : (
                  <a
                    href={show.ticketLink || '#'}
                    className="inline-block border border-white px-5 py-2 text-sm hover:bg-white hover:text-black transition"
                  >
                    Tickets
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
