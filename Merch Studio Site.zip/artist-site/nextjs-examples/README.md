# Next.js Frontend Examples

These are simple page skeletons you can adapt for either Payload or Sanity.

Place them inside your Next.js `app/` directory.
