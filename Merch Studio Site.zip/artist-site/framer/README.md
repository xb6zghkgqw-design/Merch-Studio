# Framer – Complete Setup Guide for Rap Artist Site

## 1. Create project
- New Framer project
- Set dark background and strong typography scale immediately

## 2. Design tokens
- Background: near black
- Text: white / light gray
- One accent color
- Bold headings, clean body text

## 3. Create CMS Collections
Use the exact same fields as the Webflow guide:

- Tracks (Name, Cover, Embed, Release Date, Featured)
- Videos (Title, Thumbnail, Video URL, Release Date, Featured)
- Tour Dates (Date, City, Venue, Ticket URL, Sold Out)
- Merch (Name, Price, Images, Description, Sizes, Buy Link, Featured)
- About (Bio, Photos)
- Press Kit (Short Bio, One-Sheet, Photos, Booking Email)

## 4. Build reusable components
Create these components first:
- Track Card
- Video Card
- Show Row
- Merch Card
- Footer (with newsletter form)
- Navigation

## 5. Page structure
1. Home – hero + featured track/video + merch teaser + upcoming shows
2. Music
3. Videos
4. Tour
5. Merch
6. About
7. Press

Bind every list and detail page to the CMS.

## 6. Merch
Framer does not have native full e-commerce.  
Best approach: “Buy” buttons that link to:
- Shopify
- Gumroad
- Stripe Payment Links

## 7. Newsletter
Use Framer’s form component and connect to an email service, or embed a Klaviyo/Mailchimp form.

## 8. Placeholders
Add 5–6 items per collection before designing layouts. This prevents empty states and makes spacing accurate.

## 9. Publishing & access
Publish the site and share Editor access with the artist when ready.
