# Webflow – Complete Setup Guide for Rap Artist Site

## 1. Create the site
- New site → Blank
- Choose a dark, high-contrast color system

## 2. Design system (do this first)
- Background: #0a0a0a or #000000
- Text: #ffffff / #e5e5e5
- Accent: one strong color (red, electric blue, lime, etc.)
- Headings: bold display font
- Body: clean sans-serif

## 3. Create CMS Collections

### Tracks
| Field Name     | Type        | Notes                    |
|----------------|-------------|--------------------------|
| Name           | Plain Text  | Required                 |
| Cover Image    | Image       |                          |
| Embed Code     | Long Text   | Spotify/Apple embed      |
| Release Date   | Date        |                          |
| Featured       | Switch      |                          |

### Videos
| Field Name     | Type        |
|----------------|-------------|
| Title          | Plain Text  |
| Thumbnail      | Image       |
| Video URL      | Plain Text  |
| Release Date   | Date        |
| Featured       | Switch      |

### Tour Dates
| Field Name     | Type        |
|----------------|-------------|
| Date           | Date        |
| City           | Plain Text  |
| Venue          | Plain Text  |
| Ticket URL     | Plain Text  |
| Sold Out       | Switch      |

### Merch
| Field Name     | Type              |
|----------------|-------------------|
| Product Name   | Plain Text        |
| Price          | Number            |
| Main Image     | Image             |
| Gallery        | Multi-Image       |
| Description    | Rich Text         |
| Sizes          | Plain Text        |
| Buy Link       | Plain Text        |
| Featured       | Switch            |

### About
- Bio (Rich Text)
- Photos (Multi-Image)

### Press Kit
- Short Bio (Plain Text)
- One-Sheet (File)
- High-Res Photos (Multi-Image)
- Booking Email (Plain Text)

## 4. Page build order
1. Site Settings + SEO defaults
2. Footer component (with newsletter form)
3. Home
4. Music (Collection List bound to Tracks)
5. Videos
6. Tour (sorted by Date)
7. Merch + Product template page
8. About
9. Press / Booking

## 5. Placeholders
Add 5–6 items in every collection before you design. This makes binding and spacing much easier.

## 6. Newsletter
Use a Webflow form and connect it to Mailchimp, Klaviyo, or ConvertKit.

## 7. Merch checkout
- Option A: Webflow Ecommerce
- Option B: External buy links (Shopify, Stripe Payment Links, Gumroad)

## 8. Editor access
Invite the artist with the “Editor” role so they can update content safely.
