import { defineField, defineType } from 'sanity'

export default defineType({
  name: 'home',
  title: 'Home',
  type: 'document',
  fields: [
    defineField({ name: 'heroTitle', title: 'Hero Title', type: 'string' }),
    defineField({ name: 'heroSubtitle', title: 'Hero Subtitle', type: 'string' }),
    defineField({
      name: 'featuredTrack',
      title: 'Featured Track',
      type: 'reference',
      to: [{ type: 'track' }],
    }),
    defineField({
      name: 'featuredVideo',
      title: 'Featured Video',
      type: 'reference',
      to: [{ type: 'video' }],
    }),
    defineField({ name: 'primaryCtaLabel', title: 'Primary CTA Label', type: 'string' }),
    defineField({ name: 'primaryCtaLink', title: 'Primary CTA Link', type: 'url' }),
    defineField({ name: 'secondaryCtaLabel', title: 'Secondary CTA Label', type: 'string' }),
    defineField({ name: 'secondaryCtaLink', title: 'Secondary CTA Link', type: 'url' }),
  ],
})
