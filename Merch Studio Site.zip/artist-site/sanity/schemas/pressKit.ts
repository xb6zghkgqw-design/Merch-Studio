import { defineField, defineType } from 'sanity'

export default defineType({
  name: 'pressKit',
  title: 'Press Kit',
  type: 'document',
  fields: [
    defineField({
      name: 'shortBio',
      title: 'Short Bio',
      type: 'text',
    }),
    defineField({
      name: 'oneSheet',
      title: 'One-Sheet PDF',
      type: 'file',
    }),
    defineField({
      name: 'highResPhotos',
      title: 'High-Res Photos',
      type: 'array',
      of: [{ type: 'image' }],
    }),
    defineField({
      name: 'bookingEmail',
      title: 'Booking Email',
      type: 'string',
    }),
  ],
})
