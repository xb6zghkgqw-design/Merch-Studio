import track from './track'
import video from './video'
import tourDate from './tourDate'
import merchItem from './merchItem'
import home from './home'
import siteSettings from './siteSettings'
import about from './about'
import pressKit from './pressKit'

export const schemaTypes = [
  track,
  video,
  tourDate,
  merchItem,
  home,
  siteSettings,
  about,
  pressKit,
]
