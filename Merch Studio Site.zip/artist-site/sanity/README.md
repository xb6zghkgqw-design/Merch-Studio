# Sanity + Next.js Starter

## Step-by-step

1. Create a Sanity project:
   ```bash
   npm create sanity@latest
   ```
   Choose a clean project with TypeScript.

2. Copy every file from the `schemas/` folder into your Studio `schemas/` directory.

3. Register them in `sanity.config.ts` (example included).

4. Create a Next.js app:
   ```bash
   npx create-next-app@latest web --typescript --tailwind --app
   cd web
   npm install next-sanity @sanity/image-url
   ```

5. Add environment variables:
   ```
   NEXT_PUBLIC_SANITY_PROJECT_ID=your-project-id
   NEXT_PUBLIC_SANITY_DATASET=production
   ```

6. Use the client helper and GROQ queries from the examples.

7. Open Sanity Studio and add placeholder content (or use a seed script).

## Schemas included
- track
- video
- tourDate
- merchItem
- home
- siteSettings
- about
- pressKit
